const { render } = require('ejs');
const express = require('express');
const app = express();

app.use('/static', express.static('public'));
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));

const produtos = [
  {
    id: 1,
    nome: 'IPHONE 15 PRO MAX',
    preco: 15900,
  },
  {
    id: 2,
    nome: 'IPHONE 13',
    preco: 14000,
  },
  {
    id: 3,
    nome: 'IPHONE 12',
    preco: 3000,
  },
  {
    id: 4,
    nome: 'IPHONE 11',
    preco: 1500,
  },
  {
    id: 5,
    nome: 'IPHONE Xr',
    preco: 4000,
  },
  {
    id: 6,
    nome: 'IPHONE X',
    preco: 1000,
  },
  {
    id: 7,
    nome: 'IPHONE 8 PLUS',
    preco: 950,
  },
  {
    id: 8,
    nome: 'IPHONE 7',
    preco: 800,
  },
];

const carrinho = [];

app.get('/', (req, res) => {
  res.render('login');
});

app.post('/login', (req, res) => {
  res.redirect('telainicial');
  console.log(req.body.email);
  console.log(req.body.senha);
});


app.get('/telainicial', (req, res) => {
  res.render('telainicial', { produtos: produtos });
});


app.post('/telainicial', (req, res) => {
  const productId = parseInt(req.body.productId);
  const selectedProduct = produtos.find((produto) => produto.id === productId);

  if (selectedProduct) {
    const existingProductIndex = carrinho.findIndex((item) => item.id === selectedProduct.id);

    if (existingProductIndex !== -1) {
      carrinho[existingProductIndex].quantidade += 1;
    } else {
      carrinho.push({ ...selectedProduct, quantidade: 1 });
    }

    console.log(`Produto adicionado ao carrinho: ${selectedProduct.nome}`);
  }

  res.redirect('telainicial');
});

app.get('/compras', (req, res) => {
  res.render('compras');
});

app.get('/carrinho', (req, res) => {
  const total = carrinho.reduce((acc, item) => acc + item.preco * item.quantidade, 0);
  res.render('carrinho', { carrinho: carrinho, total: total });
});

app.post('/remover-do-carrinho', (req, res) => {
  const productId = parseInt(req.body.productId);
  const existingProductIndex = carrinho.findIndex((item) => item.id === productId);

  if (existingProductIndex !== -1) {
    if (carrinho[existingProductIndex].quantidade > 1) {
      carrinho[existingProductIndex].quantidade -= 1;
    } else {
      carrinho.splice(existingProductIndex, 1);
    }

    console.log(`Produto removido do carrinho: ${carrinho[existingProductIndex].nome}`);
  }

  res.redirect('/carrinho');
});

app.post('/adicionar-ao-carrinho', (req, res) => {
  const productId = parseInt(req.body.productId);
  const selectedProduct = produtos.find((produto) => produto.id === productId);

  if (selectedProduct) {
    const existingProductIndex = carrinho.findIndex((item) => item.id === selectedProduct.id);

    if (existingProductIndex !== -1) {
      carrinho[existingProductIndex].quantidade += 1;
    } else {
      carrinho.push({ ...selectedProduct, quantidade: 1 });
    }

    console.log(`Produto adicionado ao carrinho: ${selectedProduct.nome}`);
  }

  res.redirect('/carrinho');
});


app.post('/limpar-carrinho', (req, res) => {
  carrinho.length = 0; 
  console.log('Carrinho esvaziado');
  res.redirect('/carrinho');
});

app.listen(3000, function () {
  console.log('Servidor node no ar!');
});
